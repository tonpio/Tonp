export * from '../build/NftItem/tact_NftItem';
