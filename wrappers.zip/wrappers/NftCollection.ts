export * from '../build/NftCollection/tact_NftCollection';
